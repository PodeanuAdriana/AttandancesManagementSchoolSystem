-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: Aug 13, 2023 at 10:04 AM
-- Server version: 8.0.31
-- PHP Version: 8.0.26

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `attendance_system`
--

-- --------------------------------------------------------

--
-- Table structure for table `attendences`
--

DROP TABLE IF EXISTS `attendences`;
CREATE TABLE IF NOT EXISTS `attendences` (
  `id_attendence` int NOT NULL AUTO_INCREMENT,
  `entry_h_m` float NOT NULL,
  `entry_date` float NOT NULL,
  `number_attendences` int NOT NULL,
  `id_stud` int NOT NULL,
  `id_pare` int NOT NULL,
  PRIMARY KEY (`id_attendence`),
  KEY `id_stud` (`id_stud`),
  KEY `id_pare` (`id_pare`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `attendences`
--

INSERT INTO `attendences` (`id_attendence`, `entry_h_m`, `entry_date`, `number_attendences`, `id_stud`, `id_pare`) VALUES
(1, 12.21, 12.12, 4, 1, 1),
(2, 13.2, 2.04, 5, 2, 2),
(3, 12.11, 4.05, 6, 3, 3),
(4, 13.15, 3.03, 4, 4, 4),
(5, 13.31, 27.1, 6, 5, 5),
(6, 13.41, 27.1, 5, 6, 6);

-- --------------------------------------------------------

--
-- Table structure for table `attendences_employees`
--

DROP TABLE IF EXISTS `attendences_employees`;
CREATE TABLE IF NOT EXISTS `attendences_employees` (
  `id_ae` int NOT NULL AUTO_INCREMENT,
  `id_employe` int NOT NULL,
  `id_attende` int NOT NULL,
  PRIMARY KEY (`id_ae`),
  KEY `id_employee` (`id_employe`),
  KEY `id_attendece` (`id_attende`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `attendences_employees`
--

INSERT INTO `attendences_employees` (`id_ae`, `id_employe`, `id_attende`) VALUES
(1, 3, 3),
(2, 2, 2),
(3, 4, 4),
(4, 1, 1);

-- --------------------------------------------------------

--
-- Table structure for table `auxiliary`
--

DROP TABLE IF EXISTS `auxiliary`;
CREATE TABLE IF NOT EXISTS `auxiliary` (
  `id_aux` int NOT NULL AUTO_INCREMENT,
  `post` varchar(50) NOT NULL,
  PRIMARY KEY (`id_aux`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `auxiliary`
--

INSERT INTO `auxiliary` (`id_aux`, `post`) VALUES
(1, 'ingrijitor'),
(2, 'paznic'),
(3, 'consilier'),
(4, 'medic'),
(5, 'dentist'),
(6, 'pompier');

-- --------------------------------------------------------

--
-- Table structure for table `classes`
--

DROP TABLE IF EXISTS `classes`;
CREATE TABLE IF NOT EXISTS `classes` (
  `id_class` int NOT NULL AUTO_INCREMENT,
  `profile_name` varchar(20) NOT NULL,
  `class_year` int NOT NULL,
  `class_type` varchar(4) DEFAULT NULL,
  `id_stud` int NOT NULL,
  `id_time` int NOT NULL,
  PRIMARY KEY (`id_class`),
  KEY `id_time` (`id_time`),
  KEY `id_stu` (`id_stud`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `classes`
--

INSERT INTO `classes` (`id_class`, `profile_name`, `class_year`, `class_type`, `id_stud`, `id_time`) VALUES
(1, 'info-math', 2, 'A', 1, 1),
(2, 'english-franch', 2, 'B', 2, 2),
(3, 'romainan-language', 4, 'A', 4, 3),
(5, 'history-geography', 2, 'C', 3, 4),
(6, 'info-math', 1, 'A', 5, 6),
(7, 'info-math', 3, 'B', 6, 5);

-- --------------------------------------------------------

--
-- Table structure for table `contacts`
--

DROP TABLE IF EXISTS `contacts`;
CREATE TABLE IF NOT EXISTS `contacts` (
  `id_contacts` int NOT NULL AUTO_INCREMENT,
  `phone` varchar(13) NOT NULL,
  `email` varchar(50) NOT NULL,
  PRIMARY KEY (`id_contacts`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `contacts`
--

INSERT INTO `contacts` (`id_contacts`, `phone`, `email`) VALUES
(1, '0725553121', 'damin@gmail.com'),
(2, '0733636124', 'adser@gmail.com'),
(3, '0745896214', 'fratila@gmail.com'),
(4, '07255364514', 'yutan12@gmail.com'),
(5, '0789445621', 'angela14irina@gmail'),
(6, '0739964215', 'emaioana21@gmail.com');

-- --------------------------------------------------------

--
-- Table structure for table `courses`
--

DROP TABLE IF EXISTS `courses`;
CREATE TABLE IF NOT EXISTS `courses` (
  `id_course` int NOT NULL AUTO_INCREMENT,
  `name_course` varchar(50) NOT NULL,
  `nr_courses` int NOT NULL,
  PRIMARY KEY (`id_course`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `courses`
--

INSERT INTO `courses` (`id_course`, `name_course`, `nr_courses`) VALUES
(1, 'math', 4),
(2, 'romainian language', 4),
(3, 'english language', 2),
(4, 'franch language', 2),
(5, 'geography', 2),
(6, 'history', 2);

-- --------------------------------------------------------

--
-- Table structure for table `employees`
--

DROP TABLE IF EXISTS `employees`;
CREATE TABLE IF NOT EXISTS `employees` (
  `id_employees` int NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `last_name` varchar(50) NOT NULL,
  `id_aux` int NOT NULL,
  `id_teacher` int NOT NULL,
  `id_leave` int NOT NULL,
  `id_salary` int NOT NULL,
  `id_contacts` int NOT NULL,
  PRIMARY KEY (`id_employees`),
  KEY `id_leave` (`id_leave`),
  KEY `id_salary` (`id_salary`),
  KEY `id_contacts` (`id_contacts`),
  KEY `id_auxili` (`id_aux`),
  KEY `id_prof` (`id_teacher`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `employees`
--

INSERT INTO `employees` (`id_employees`, `name`, `last_name`, `id_aux`, `id_teacher`, `id_leave`, `id_salary`, `id_contacts`) VALUES
(1, 'Stroe', 'Nicolae', 3, 6, 1, 1, 2),
(2, 'Iulica', 'Ema', 1, 6, 3, 2, 1),
(3, 'Edmundo', 'Edward', 4, 6, 4, 4, 3),
(4, 'Costache', 'Irinel', 2, 6, 3, 2, 4);

-- --------------------------------------------------------

--
-- Table structure for table `leave`
--

DROP TABLE IF EXISTS `leave`;
CREATE TABLE IF NOT EXISTS `leave` (
  `id_leave` int NOT NULL AUTO_INCREMENT,
  `type_leave` varchar(50) NOT NULL,
  `nr_days` int NOT NULL,
  `start_date` float NOT NULL,
  `end_date` float NOT NULL,
  PRIMARY KEY (`id_leave`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `leave`
--

INSERT INTO `leave` (`id_leave`, `type_leave`, `nr_days`, `start_date`, `end_date`) VALUES
(1, 'holiday', 5, 21, 26),
(2, 'holiday', 3, 1.07, 4.07),
(3, 'holiday', 4, 1.08, 5.08),
(4, 'sick', 2, 3.03, 5.03),
(5, 'holiday', 3, 23.12, 26.12),
(6, 'sick', 5, 12.1, 17.1);

-- --------------------------------------------------------

--
-- Table structure for table `parents`
--

DROP TABLE IF EXISTS `parents`;
CREATE TABLE IF NOT EXISTS `parents` (
  `id_parents` int NOT NULL AUTO_INCREMENT,
  `name_parent` varchar(50) NOT NULL,
  `ln_parent` varchar(50) NOT NULL,
  `id_stud` int NOT NULL,
  PRIMARY KEY (`id_parents`),
  KEY `id_st` (`id_stud`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `parents`
--

INSERT INTO `parents` (`id_parents`, `name_parent`, `ln_parent`, `id_stud`) VALUES
(1, 'Podeanu', 'Irina', 6),
(2, 'Martinica', 'Elena', 2),
(3, 'Stan', 'Gheorghe', 4),
(4, 'Iliescu', 'Teodor', 5),
(5, 'Popa', 'Claudiu', 3),
(6, 'Florenta', 'Maria', 1);

-- --------------------------------------------------------

--
-- Table structure for table `students`
--

DROP TABLE IF EXISTS `students`;
CREATE TABLE IF NOT EXISTS `students` (
  `id_student` int NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `last_name` varchar(50) NOT NULL,
  `age` int NOT NULL,
  PRIMARY KEY (`id_student`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `students`
--

INSERT INTO `students` (`id_student`, `name`, `last_name`, `age`) VALUES
(1, 'Martinica', 'Ene', 13),
(2, 'Florenta', 'Ion', 10),
(3, 'Popa', 'Marius', 12),
(4, 'Stan', 'Marina', 7),
(5, 'Iliescu', 'Serban', 11),
(6, 'Podeanu', 'Stefania', 15);

-- --------------------------------------------------------

--
-- Table structure for table `teachers`
--

DROP TABLE IF EXISTS `teachers`;
CREATE TABLE IF NOT EXISTS `teachers` (
  `id_teacher` int NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `last_name` varchar(50) NOT NULL,
  `specialization` varchar(50) NOT NULL,
  `degree` varchar(20) NOT NULL,
  PRIMARY KEY (`id_teacher`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `teachers`
--

INSERT INTO `teachers` (`id_teacher`, `name`, `last_name`, `specialization`, `degree`) VALUES
(1, 'Stanescu', 'Florin', 'math', '3'),
(2, 'Ionescu', 'Silvia', 'informatica', '2'),
(3, 'Maricica', 'Elena', 'geography', '2'),
(4, 'Stancu', 'Maria', 'history', '1'),
(5, 'Stroe', 'Ioan', 'english language', '3'),
(6, '-', '-', '-', '-');

-- --------------------------------------------------------

--
-- Table structure for table `teach_courses`
--

DROP TABLE IF EXISTS `teach_courses`;
CREATE TABLE IF NOT EXISTS `teach_courses` (
  `id_te_cou` int NOT NULL AUTO_INCREMENT,
  `id_lesson` int NOT NULL,
  `id_class` int NOT NULL,
  `id_prf` int NOT NULL,
  PRIMARY KEY (`id_te_cou`),
  KEY `id_less` (`id_lesson`),
  KEY `id_cls` (`id_class`),
  KEY `id_prf` (`id_prf`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `teach_courses`
--

INSERT INTO `teach_courses` (`id_te_cou`, `id_lesson`, `id_class`, `id_prf`) VALUES
(1, 3, 1, 4),
(2, 4, 2, 2),
(3, 5, 6, 3),
(4, 6, 5, 1),
(5, 2, 3, 5),
(6, 1, 7, 4);

-- --------------------------------------------------------

--
-- Table structure for table `timetable`
--

DROP TABLE IF EXISTS `timetable`;
CREATE TABLE IF NOT EXISTS `timetable` (
  `cod_timetable` int NOT NULL AUTO_INCREMENT,
  `start_time` float NOT NULL,
  `end_time` float NOT NULL,
  PRIMARY KEY (`cod_timetable`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `timetable`
--

INSERT INTO `timetable` (`cod_timetable`, `start_time`, `end_time`) VALUES
(1, 12.3, 13.2),
(2, 13.3, 14.2),
(3, 14.3, 15.2),
(4, 15.3, 16.2),
(5, 16.3, 17.2),
(6, 17.3, 18.2),
(7, 18.3, 19.2);

-- --------------------------------------------------------

--
-- Table structure for table `wages`
--

DROP TABLE IF EXISTS `wages`;
CREATE TABLE IF NOT EXISTS `wages` (
  `id_salary` int NOT NULL AUTO_INCREMENT,
  `net_salary` int NOT NULL,
  `bouneses` int NOT NULL,
  `age` int NOT NULL,
  PRIMARY KEY (`id_salary`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `wages`
--

INSERT INTO `wages` (`id_salary`, `net_salary`, `bouneses`, `age`) VALUES
(1, 4000, 2000, 25),
(2, 5000, 2000, 30),
(3, 4500, 2500, 35),
(4, 5000, 3000, 37),
(5, 1500, 1000, 3),
(6, 2000, 1500, 5);

--
-- Constraints for dumped tables
--

--
-- Constraints for table `attendences`
--
ALTER TABLE `attendences`
  ADD CONSTRAINT `id_pare` FOREIGN KEY (`id_pare`) REFERENCES `parents` (`id_parents`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `id_stud` FOREIGN KEY (`id_stud`) REFERENCES `students` (`id_student`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `attendences_employees`
--
ALTER TABLE `attendences_employees`
  ADD CONSTRAINT `id_attendece` FOREIGN KEY (`id_attende`) REFERENCES `attendences` (`id_attendence`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `id_employee` FOREIGN KEY (`id_employe`) REFERENCES `employees` (`id_employees`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `classes`
--
ALTER TABLE `classes`
  ADD CONSTRAINT `id_stu` FOREIGN KEY (`id_stud`) REFERENCES `students` (`id_student`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `id_time` FOREIGN KEY (`id_time`) REFERENCES `timetable` (`cod_timetable`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `employees`
--
ALTER TABLE `employees`
  ADD CONSTRAINT `id_auxili` FOREIGN KEY (`id_aux`) REFERENCES `auxiliary` (`id_aux`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `id_contacts` FOREIGN KEY (`id_contacts`) REFERENCES `contacts` (`id_contacts`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `id_leave` FOREIGN KEY (`id_leave`) REFERENCES `leave` (`id_leave`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `id_prof` FOREIGN KEY (`id_teacher`) REFERENCES `teachers` (`id_teacher`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `id_salary` FOREIGN KEY (`id_salary`) REFERENCES `wages` (`id_salary`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `parents`
--
ALTER TABLE `parents`
  ADD CONSTRAINT `id_st` FOREIGN KEY (`id_stud`) REFERENCES `students` (`id_student`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `teach_courses`
--
ALTER TABLE `teach_courses`
  ADD CONSTRAINT `id_cls` FOREIGN KEY (`id_class`) REFERENCES `classes` (`id_class`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `id_less` FOREIGN KEY (`id_lesson`) REFERENCES `courses` (`id_course`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `id_prf` FOREIGN KEY (`id_prf`) REFERENCES `teachers` (`id_teacher`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
